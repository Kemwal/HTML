function getBill(){
	txtgnm=document.getElementById("txtgnm");
	txtsty=document.getElementById("txtsty");
	txtfb=document.getElementById("txtfb");
	txtnet=document.getElementById("txtnet");
	txtadv=document.getElementById("txtadv");
	txtgst=document.getElementById("txtgst");
	selmode=document.getElementById("selmode");
	
	gnm=txtgnm.value;
	sty=parseInt(txtsty.value);
	fb=parseFloat(txtfb.value);
	net=parseFloat(txtnet.value);
	adv=parseFloat(txtadv.value);
	gst=parseFloat(txtgst.value);
	mode=selmode.value;
	
	//computing gross bill assuming Rs.800 per day
	gbamt=(sty*800) + net + fb;
	
	//compute net bill
	nbamt=gbamt + (gbamt*(gst/100));
	
	//compute payable amount
	pbamt = nbamt - adv;
	outputWin=open();
	outputWin.document.writeln("<h1>Mapple Something Internationl");
	outputWin.document.writeln("<table>");
	
	outputWin.document.writeln("<tr>");
	outputWin.document.writeln("<td>Guest name:</td>");
	outputWin.document.writeln("<td>"+gnm+"</td>");
	outputWin.document.writeln("</tr>");
	
	outputWin.document.writeln("<tr>");
	outputWin.document.writeln("<td>Stay:</td>");
	outputWin.document.writeln("<td>"+sty+" days</td>");
	outputWin.document.writeln("</tr>");
	
	outputWin.document.writeln("<tr>");
	outputWin.document.writeln("<td>Food Bill:</td>");
	outputWin.document.writeln("<td>"+fb+"</td>");
	outputWin.document.writeln("</tr>");
	
	outputWin.document.writeln("<tr>");
	outputWin.document.writeln("<td>Net Usage:</td>");
	outputWin.document.writeln("<td>"+net+"</td>");
	outputWin.document.writeln("</tr>");
	
	outputWin.document.writeln("<tr>");
	outputWin.document.writeln("<td>Advance Payment:</td>");
	outputWin.document.writeln("<td>"+adv+"</td>");
	outputWin.document.writeln("</tr>");
	
	outputWin.document.writeln("<tr>");
	outputWin.document.writeln("<td>Gross Bill:</td>");
	outputWin.document.writeln("<td>"+gbamt+"</td>");
	outputWin.document.writeln("</tr>");
	
	outputWin.document.writeln("<tr>");
	outputWin.document.writeln("<td>Net Bill:</td>");
	outputWin.document.writeln("<td>"+nbamt+"</td>");
	outputWin.document.writeln("</tr>");
	
	outputWin.document.writeln("<tr>");
	outputWin.document.writeln("<td>Payable Amount:</td>");
	outputWin.document.writeln("<td>"+pbamt+"</td>");
	outputWin.document.writeln("</tr>");
	outputWin.document.writeln("<tr>");
	outputWin.document.writeln("<td>Payment Mode:</td>");
	outputWin.document.writeln("<td>"+mode+"</td>");
	outputWin.document.writeln("</tr>");
	
	
}